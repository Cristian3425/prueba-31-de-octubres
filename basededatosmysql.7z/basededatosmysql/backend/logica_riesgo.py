def calcular_riesgo(inasistencias, rendimiento, participacion):
    """
    Función que calcula el porcentaje de riesgo de deserción.

    Argumentos:
        inasistencias (int): Número de faltas.
        rendimiento (float): Nota promedio (ej. 4.5).
        participacion (bool): Si es True (participa) o False (no participa).

    Retorna:
        float: El porcentaje de riesgo ajustado (0.0 a 100.0).
    """
    
    # comenzamos con un riesgo base de 50%.
    riesgo_base = 50.0 
    riesgo_ajustado = riesgo_base

    
    # LÓGICA DE FACTORES NEGATIVOS (AUMENTAN EL RIESGO)
    

    # Inasistencias: Sumamos 5% por cada falta, con un tope de 50% de aumento.
    aumento_inasistencias = min(inasistencias * 5, 50)
    riesgo_ajustado += aumento_inasistencias

    # Rendimiento Académico: Si la nota es muy baja (< 3.0), sumamos riesgo.
    if rendimiento < 3.0:
        riesgo_ajustado += 15  # Un factor de riesgo significativo por bajo rendimiento.
    
    
    # LÓGICA DE FACTORES POSITIVOS (DISMINUYEN EL RIESGO)
    

    # Rendimiento Académico: Si la nota es alta (>= 4.5), disminuimos el riesgo.
    elif rendimiento >= 4.5:
        riesgo_ajustado -= 10  # Descuento de riesgo por buen desempeño.

    # Participación en Proyectos: Si el aprendiz participa, descontamos riesgo.
    if participacion:
        riesgo_ajustado -= 10 # Descuento por compromiso y actividad.

    # AJUSTE FINAL
    
    # Aseguramos que el resultado no sea menor que 0 ni mayor que 100.
    riesgo_final = max(0, min(100, riesgo_ajustado))
    
    return riesgo_final