from flask import Flask, request, jsonify # Importo las herramientas de Flask


# Como app.py, logica_riesgo.py y database.py están en la misma carpeta (backend),
# usamos '.' (punto) para importar dentro del mismo paquete.
from .logica_riesgo import calcular_riesgo # Importo la función central
from .database import guardar_datos_analisis # Importo la función de la DB
# ----------------------------------------------------


app = Flask(__name__) # Inicio la aplicación Flask 

# --- RUTA PRINCIPAL DE ANÁLISIS ---

@app.route('/api/riesgo/analizar', methods=['POST'])
def analizar_riesgo():
    """
    Endpoint (Ruta) que recibe los datos de un aprendiz, 
    calcula el riesgo de deserción y guarda el resultado.
    """
    
    # 1. RECIBIR DATOS
    # Espero un JSON con los factores desde el Frontend o Postman.
    datos = request.get_json()
    
    # Verifico que todos los campos requeridos estén en el JSON
    if not all(key in datos for key in ['id_aprendiz', 'inasistencias', 'rendimiento', 'participacion']):
        # Si faltan datos, devuelve un error 400 (Bad Request).
        return jsonify({"error": "Faltan datos en la solicitud JSON"}), 400

    try:
        #  EXTRAER Y CONVERTIR DATOS
        # Extraigo los datos del JSON y me aseguro de que tengan el tipo correcto (int/float/).
        id_aprendiz = int(datos['id_aprendiz'])
        inasistencias = int(datos['inasistencias'])
        rendimiento = float(datos['rendimiento'])
        
        # La participación puede venir como string ("true") o booleano (true), la normalizamos a bool
        # Corrijo la lógica de normalización para que sea más clara
        participacion_raw = datos['participacion']
        if isinstance(participacion_raw, str):
             participacion = participacion_raw.lower() == 'true'
        else:
             # Si ya es un booleano (o cualquier otro tipo), lo mantenemos.
             participacion = bool(participacion_raw) 

        #  CALCULAR EL RIESGO
        porcentaje_riesgo = calcular_riesgo(
            inasistencias, 
            rendimiento, 
            participacion
        )
        
        #  GUARDAR EL RESULTADO EN LA BASE DE DATOS
        db_guardado_exitoso = guardar_datos_analisis(
            id_aprendiz, 
            inasistencias, 
            rendimiento, 
            participacion, 
            porcentaje_riesgo
        )

        #  GENERAR RESPUESTA
        respuesta = {
            "id_aprendiz": id_aprendiz,
            "riesgo_calculado": porcentaje_riesgo,
            "estado_db": "Guardado exitoso" if db_guardado_exitoso else "Error al guardar en DB"
        }
        
        # Devuelve el resultado al cliente como JSON con código 200 (OK).
        return jsonify(respuesta), 200

    except ValueError:
        # Atrapo errores si por ejemplo, el 'rendimiento' no es un número.
        return jsonify({"error": "Los datos de entrada tienen un formato incorrecto (esperando números)."}), 400
    except Exception as e:
        # Atrapamos cualquier otro error inesperado.
        return jsonify({"error": f"Ocurrió un error interno del servidor: {str(e)}"}), 500

# Punto de entrada para iniciar el servidor de Flask
if __name__ == '__main__':
    # Ejecutamos la aplicación. 'debug=True' permite recargas automáticas durante el desarrollo.
    app.run(debug=True, port=5000)
