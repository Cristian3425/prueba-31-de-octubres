import pymysql.cursors
from datetime import datetime

# --- CONFIGURACIÓN DE CONEXIÓN ---

DB_HOST = 'localhost'       # Generalmente 'localhost' si usas XAMPP/WAMP
DB_USER = 'root'            # El usuario de my sql
DB_PASSWORD = '1234567' #  contraseña de la base de datos de mysql
DB_NAME = 'Porcentaje_caracterizacion' # Nombre de la base de datos que creamos
DB_PORT = 3308             # Puerto estándar de MySQL

def obtener_conexion():
    """Conecta a la base de datos MySQL y devuelve el objeto de conexión."""
    try:
        # intentamos establecer conexion
        conexion = pymysql.connect(
            host=DB_HOST,
            user=DB_USER,
            password=DB_PASSWORD,
            db=DB_NAME,
            charset='utf8mb4', # Usamos el mismo charset que definimos en el SQL
            cursorclass=pymysql.cursors.DictCursor # Esto nos devuelve los resultados como diccionarios (más fácil de manejar)
        )
        return conexion
    except pymysql.Error as e:
        # Si algo falla, lo imprimimos para saber qué pasó
        print(f"Error al conectar a MySQL: {e}")
        return None

def guardar_datos_analisis(id_aprendiz, inasistencias, rendimiento, participacion, riesgo_porcentaje):
    """Inserta el resultado del análisis en la tabla factores_riesgo."""
    
    conexion = obtener_conexion()
    if conexion is None:
        return False

    try:
        with conexion.cursor() as cursor:
            # Comando SQL para insertar los datos en la tabla.
            sql = """
            INSERT INTO factores_riesgo (
                id_aprendiz, 
                inasistencias, 
                rendimiento_academico, 
                participacion_proyectos, 
                riesgo_porcentaje
            ) VALUES (%s, %s, %s, %s, %s)
            """
            
            # Ejecutamos el comando SQL, pasando las variables como tupla de datos
            cursor.execute(sql, (
                id_aprendiz, 
                inasistencias, 
                rendimiento, 
                participacion, 
                riesgo_porcentaje
            ))

        # Es crucial hacer un 'commit' para que los cambios se guarden permanentemente en la base de datos.
        conexion.commit()
        return True
        
    except pymysql.Error as e:
        print(f"Error al guardar datos de análisis: {e}")
        # Si algo falló, deshacemos cualquier cambio pendiente (rollback)
        conexion.rollback()
        return False
        
    finally:
        # Siempre cerramos la conexión para liberar recursos.
        if conexion:
            conexion.close()