-- este comando borra la base de datos
DROP DATABASE IF EXISTS Porcentaje_caracterización; 

-- == CONFIGURACIÓN INICIAL DE LA BASE DE DATOS ==

-- Paso 1: Creamos la base de datos que vamos a usar. ¡Aquí va a vivir toda nuestra info!
CREATE DATABASE Porcentaje_caracterización ;
    
-- Entramos a la base de datos para empezar a trabajar en ella.
USE Porcentaje_caracterización;

-- == TABLA DE INFORMACIÓN BÁSICA DEL APRENDIZ ==
-- Paso 2: Creamos la tabla principal 'aprendices'.

-- Vamos a guardar lo esencial de cada persona.
CREATE TABLE aprendices (
       id_aprendiz INT AUTO_INCREMENT PRIMARY KEY,   -- Este es el ID único. Es la llave maestra (PRIMARY KEY) y se va a numerar sola (AUTO_INCREMENT).id_aprendiz INT AUTO_INCREMENT PRIMARY KEY,
	nombre VARCHAR(100) NOT NULL, -- El nombre completo. No debe ir vacío (NOT NULL) y le damos un espacio de 100 caracteres.
       programa VARCHAR(100) NOT NULL   -- El programa o curso al que pertenece. También es obligatorio (NOT NULL).
);

-- == TABLA PARA GUARDAR LOS FACTORES DE RIESGO ==
-- Paso 3: Creamos la tabla 'factores_riesgo', la más importante para la lógica del negocio.

-- Esta tabla va a almacenar el resultado del análisis y los datos clave.
CREATE TABLE factores_riesgo (
                  id_riesgo INT AUTO_INCREMENT PRIMARY KEY,  -- ID de cada análisis que se haga. Cada fila es un 'snapshot' de riesgo.
				  id_aprendiz INT NOT NULL, -- El ID del aprendiz al que le estamos calculando el riesgo. Siempre debe estar ligado a alguien (NOT NULL).
				inasistencias INT DEFAULT 0, -- Cuántas faltas tiene. Si no me dan un número, asumimos que son 0 (DEFAULT 0).
				rendimiento_academico DECIMAL(3, 2) DEFAULT 0.00, -- El promedio académico. Solo queremos un decimal 
                participacion_proyectos BOOLEAN DEFAULT FALSE,   -- Si participa o no. Es un simple SÍ/NO (BOOLEAN). Por defecto, no participa (FALSE).
               riesgo_porcentaje DECIMAL(5, 2) NOT NULL,     -- El resultado del porcentaje de riesgo de deserción 
                fecha_analisis DATETIME DEFAULT CURRENT_TIMESTAMP,  -- La fecha y hora exacta en que se hizo este análisis. Se pone automáticamente (DEFAULT CURRENT_TIMESTAMP).
               FOREIGN KEY (id_aprendiz) REFERENCES aprendices(id_aprendiz)   --  Con esto decimos que el 'id_aprendiz' de esta tabla tiene que existir en la tabla 'aprendices'.
);