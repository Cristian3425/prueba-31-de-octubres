# Sistema de Predicción de Riesgo de Deserción

## Descripción del Proyecto

Este proyecto implementa un sistema para analizar diversos factores de un aprendiz e identificar la probabilidad o **porcentaje del nivel de riesgo de deserción**. El sistema utiliza una API REST (Backend con Python/Flask) para recibir datos, aplicar una lógica de negocio y registrar el resultado en una base de datos MySQL.

**Componentes:**
1.  **Backend (Python/Flask):** Lógica de cálculo y API.
2.  **Base de Datos (MySQL):** Almacenamiento de aprendices y resultados de riesgo.
3.  **Testeo (unittest y Postman):** Verificación de la lógica y la API.

---

## Requisitos y Configuración

Necesitas tener instalados los siguientes elementos:

1.  **Python 3.x**
2.  **MySQL Server** (O un entorno como XAMPP/WAMP que incluya MySQL).
3.  **Visual Studio Code** (O tu IDE preferido).
4.  **Postman** (Para probar la API).

### 1. Instalación de Dependencias Python

Abre la terminal en la carpeta raíz del proyecto y sigue estos pasos:

1.  **Crea el entorno virtual:**
    ```bash
    python -m venv .venv
    ```
2.  **Activa el entorno:**
    * **Windows (CMD/PowerShell):** `.\.venv\Scripts\activate`
3.  **Instala Flask y el conector MySQL:**
    ```bash
    pip install Flask PyMySQL
    ```

### 2. Configuración de la Base de Datos

1.  Abre tu cliente MySQL (o phpMyAdmin).
2.  Ejecuta el script SQL en `sql/01_schema.sql` para crear la base de datos `Porcentaje_caracterizacion` y sus tablas.
3.  **IMPORTANTE:** Edita el archivo `backend/database.py` y actualiza las variables `DB_PASSWORD`, `DB_USER`, etc., con tus credenciales.

---

## Uso y Ejecución del Sistema

### 1. Iniciar el Backend (API)

Desde la terminal activada, ejecuta:

```bash
python backend/app.py