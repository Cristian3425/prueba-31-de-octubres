import unittest
# Importamos la función de modificación de rutas para asegurar que encuentre 'backend'
import sys
import os

# --- INICIO DE LA CORRECCIÓN ROBUSTA DE PATH ---
# Obtenemos la ruta del directorio padre (la carpeta 'basededatosmysql')
ruta_raiz = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
# Insertamos la ruta raíz al inicio del path de búsqueda de Python
sys.path.insert(0, ruta_raiz)
# --- FIN DE LA CORRECCIÓN ROBUSTA DE PATH ---

# La importación debe funcionar ahora. Si no funciona, el problema es el __init__.py
from backend.logica_riesgo import calcular_riesgo


class TestRiesgoDesercion(unittest.TestCase):
    """
    Conjunto de pruebas para la función calcular_riesgo().
    """
    
    def test_caso_alto_riesgo(self):
        resultado = calcular_riesgo(inasistencias=3, rendimiento=2.5, participacion=False)
        self.assertEqual(resultado, 80.0, "ERROR: El riesgo no es alto para condiciones desfavorables.")

    def test_caso_bajo_riesgo(self):
        resultado = calcular_riesgo(inasistencias=0, rendimiento=4.8, participacion=True)
        self.assertEqual(resultado, 30.0, "ERROR: El riesgo no es bajo para condiciones favorables.")

    def test_limite_superior_100(self):
        resultado = calcular_riesgo(inasistencias=15, rendimiento=1.0, participacion=False)
        self.assertEqual(resultado, 100.0, "ERROR: El límite máximo debe ser 100.0.")
    
    def test_caso_neutro(self):
        resultado = calcular_riesgo(inasistencias=0, rendimiento=3.5, participacion=False)
        self.assertEqual(resultado, 50.0, "ERROR: El riesgo neutro debe ser 50.0.")

if __name__ == '__main__':
    unittest.main()